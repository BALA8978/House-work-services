<?php
// Temporarily suppress all PHP errors and warnings from being displayed to the browser
// This is crucial for ensuring valid JSON output.
error_reporting(0);
ini_set('display_errors', 0);

session_start();

// Set the content type header to JSON
header('Content-Type: application/json');

// Initialize a default response array
$response = ['success' => false, 'message' => 'An unknown error occurred.'];

try {
    // Include the central database connection file
    // Make sure the path to db_connect.php is correct relative to this file.
    // Assuming db_connect.php is in '../../config/db_connect.php' based on previous context.
    include '../../config/db_connect.php';

    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        $response['message'] = 'You must be logged in to apply.';
        echo json_encode($response);
        exit();
    }

    // Retrieve form data
    $user_id = $_SESSION['user_id'];
    $full_name = $_POST['full_name'] ?? '';
    $gender = $_POST['gender'] ?? ''; // New field
    $phone_number = $_POST['phone_number'] ?? '';
    $area = $_POST['area'] ?? '';     // New field
    $skills = $_POST['skills'] ?? '';

    // Basic validation for required fields
    if (empty($full_name) || empty($gender) || empty($phone_number) || empty($area) || empty($skills) || !isset($_FILES['documents'])) {
        $response['message'] = 'All fields and documents are required.';
        echo json_encode($response);
        exit();
    }

    // Handle file upload for supporting documents
    $target_dir = "uploads/";
    // Create the uploads directory if it doesn't exist
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true); // 0777 for full permissions, adjust as needed for production
    }

    $uploaded_file_name = basename($_FILES["documents"]["name"]);
    $target_file = $target_dir . $uploaded_file_name;
    $documents_path = ''; // Initialize path
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file is an actual image or PDF
    // Using finfo_open for more robust MIME type checking
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES['documents']['tmp_name']);
    finfo_close($finfo);

    $allowed_mimes = ['application/pdf', 'image/jpeg', 'image/png'];

    if (!in_array($mime, $allowed_mimes)) {
        $response['message'] = 'Invalid file type. Only PDF, JPG, and PNG files are allowed.';
        echo json_encode($response);
        exit();
    }

    // Check file size (5MB limit)
    if ($_FILES["documents"]["size"] > 5000000) {
        $response['message'] = 'Sorry, your file is too large. Maximum size is 5MB.';
        echo json_encode($response);
        exit();
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES["documents"]["tmp_name"], $target_file)) {
        $documents_path = $target_file;
    } else {
        $response['message'] = 'Sorry, there was an error uploading your file.';
        echo json_encode($response);
        exit();
    }

    // Insert into technician_profiles table
    // Updated SQL query to include gender, area, and documents_path
    $sql = "INSERT INTO technician_profiles (user_id, full_name, gender, phone_number, area, skills, documents_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
    $stmt = $conn->prepare($sql);

    // Check if the statement preparation was successful
    if ($stmt === false) {
        $response['message'] = 'Database statement preparation failed: ' . $conn->error;
        echo json_encode($response);
        exit();
    }

    // Bind parameters: 'i' for integer, 's' for string
    // The types should match the order of columns in the SQL query
    // user_id (int), full_name (string), gender (string), phone_number (string), area (string), skills (string), documents_path (string)
    $bind_success = $stmt->bind_param("issssss", $user_id, $full_name, $gender, $phone_number, $area, $skills, $documents_path);

    if ($bind_success === false) {
        $response['message'] = 'Binding parameters failed: ' . $stmt->error;
        echo json_encode($response);
        exit();
    }

    // Execute the statement
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Application submitted successfully! You will be notified once it is reviewed.';
    } else {
        // Check for duplicate entry error (e.g., if user_id is unique and already exists)
        if ($conn->errno == 1062) {
            $response['message'] = 'You have already submitted an application.';
        } else {
            $response['message'] = 'Failed to submit application. Please try again. Database Error: ' . $stmt->error;
        }
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    // Catch any unexpected exceptions and log them
    // Re-enable error reporting temporarily to log the error to the server's error log
    error_reporting(E_ALL);
    ini_set('display_errors', 1); // This will only affect logging, not display to browser due to header
    error_log("apply.php Error: " . $e->getMessage() . " on line " . $e->getLine());
    $response['message'] = 'An unexpected server error occurred. Please try again later.';
}

// Always ensure a JSON response is sent
echo json_encode($response);
?>
