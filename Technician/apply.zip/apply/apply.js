document.getElementById('application-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const message = document.getElementById('message');

    fetch('apply.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            message.textContent = 'Application submitted successfully! You will be notified once it is reviewed.';
            message.className = 'message success';
            form.reset();
        } else {
            message.textContent = data.message;
            message.className = 'message error';
        }
    })
    .catch(error => {
        message.textContent = 'An error occurred. Please try again.';
        message.className = 'message error';
        console.error('Error:', error);
    });
});
