document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    const messageArea = document.getElementById('register-message');
    const roleInputs = document.querySelectorAll('input[name="role"]');

    registerForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const formData = new FormData(registerForm);
        const selectedRole = formData.get('role'); // Get the selected role

        // Disable the button to prevent multiple submissions
        const submitButton = registerForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';

        // Make a POST request to the register.php script
        fetch('register.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json()) // Process the response as JSON
        .then(data => {
            // Display the response message from the server
            messageArea.textContent = data.message;

            if (data.success) {
                messageArea.className = 'success';
                registerForm.reset(); // Clear the form on success

                // --- NEW: Conditional Redirection Logic ---
                setTimeout(() => {
                    if (selectedRole === 'technician') {
                        // If the user is a technician, redirect to the apply page
                        window.location.href = '../../apply/index.html';
                    } else {
                        // If the user is a customer, redirect to the login page
                        window.location.href = '../loginpage/index.html';
                    }
                }, 2000); // 2-second delay for the user to read the message

            } else {
                messageArea.className = 'error';
                // Re-enable the button on failure
                submitButton.disabled = false;
                submitButton.textContent = 'Create Account';
            }
        })
        .catch(error => {
            // Handle network or other errors
            messageArea.className = 'error';
            messageArea.textContent = 'An error occurred. Please try again.';
            console.error('Error:', error);
            // Re-enable the button on failure
            submitButton.disabled = false;
            submitButton.textContent = 'Create Account';
        });
    });
});
