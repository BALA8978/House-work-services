<?php
/*
 * File: register.php (Updated with Admin Approval Workflow)
 *
 * This script now directs technician registrations to a pending table
 * for admin approval, while customers are registered directly.
 */

// Set the header to specify JSON content
header('Content-Type: application/json');

// Include the database connection
require 'db_connect.php'; //

$response = ['success' => false, 'message' => 'Invalid request method.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = trim($_POST['role'] ?? '');

    // Validate the data
    if (empty($full_name) || empty($email) || empty($password) || empty($role)) {
        $response['message'] = "Error: All fields are required.";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // --- NEW: Conditional logic based on user role ---
        if ($role === 'customer') {
            // --- CUSTOMER WORKFLOW: Insert directly into the main users table ---
            $sql = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $role);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = "Registration successful! You can now log in.";
                $response['role'] = 'customer';
            } else {
                if ($conn->errno == 1062) {
                    $response['message'] = "Error: This email address is already registered.";
                } else {
                    $response['message'] = "Error during registration: " . $stmt->error;
                }
            }
            $stmt->close();

        } elseif ($role === 'technician') {
            // --- TECHNICIAN WORKFLOW: Insert into the pending_technicians table for admin review ---
            $sql = "INSERT INTO pending_technicians (full_name, email, password_hash) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $full_name, $email, $hashed_password);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = "Application submitted! Your registration is pending admin review.";
                $response['role'] = 'technician';
            } else {
                if ($conn->errno == 1062) {
                    $response['message'] = "Error: This email address has already been submitted for review.";
                } else {
                    $response['message'] = "Error during submission: " . $stmt->error;
                }
            }
            $stmt->close();
        } else {
            $response['message'] = "Invalid role specified.";
        }
    }
}

// Close the connection and send the JSON response
$conn->close();
echo json_encode($response);
?>